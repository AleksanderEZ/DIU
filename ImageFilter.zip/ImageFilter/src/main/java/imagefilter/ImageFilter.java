import view.Display;

public class ImageFilter {

    public static void main(String[] args) {
        Display display = new Display();
        display.run();
    }
}
