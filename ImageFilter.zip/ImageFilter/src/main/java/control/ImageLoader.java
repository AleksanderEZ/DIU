package control;

import java.awt.image.BufferedImage;

public interface ImageLoader {

    BufferedImage load(String path);
}
